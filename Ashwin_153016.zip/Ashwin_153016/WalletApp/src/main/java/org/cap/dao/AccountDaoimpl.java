package org.cap.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;


import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
@Transactional
public class AccountDaoimpl implements AccountDao {

	
		@PersistenceContext(type=PersistenceContextType.EXTENDED)
		EntityManager entitymanager;
       
	   @Override
       public void createAccount(Account account) {
              
    	   Query query= entitymanager.createQuery("select max(accountNo) from Account");
              
           List<Long> max= query.getResultList();
                     
            account.setAccountNo(max.get(0)+1);
        	
            entitymanager.persist(account);
       }
       

       @Override
       @Transactional(readOnly=true)
       public List<Account> getAllAccounts(int customerId) {
              
              Query query= entitymanager.createQuery("from Account acc where acc.customer.customerId=:custId");
              
              query.setParameter("custId", customerId);
             
              List<Account> accounts= query.getResultList();
               
         return accounts;
       }
       
       
       
       @Transactional(readOnly=true)
       public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId){
       
              Query query2=entitymanager.createQuery(strQuery);
              
              query2.setParameter("custId", customerId);
              
              List<Transaction> transactions=query2.getResultList();
              Map<Account, Double> map = transactions.stream().collect(
                           Collectors.groupingBy(Transaction::getFromAccount,
                           Collectors.summingDouble(Transaction::getAmount))
                           );
         return map;
       }
       
       public void deposit(String accountno, int amount) {

               double newBalance = 0;

               Query q1 = entitymanager.createQuery("From Account SA WHERE SA.accountno=?");
               List<Account> SA = q1.getResultList();
               for (Account sav : SA) {
                   newBalance = sav.getUpdateBalance() + amount;
               }

               Query q = entitymanager.createQuery("update Account set balance=? where accountno=?");
               q.setParameter(0, accountno);
               q.setParameter(1, newBalance);
               q.executeUpdate();

               entitymanager.flush();

           }


      

	@Override
	public Account findAccount(long accnum) {
		
		Query query= entitymanager.createQuery("from Account where accountNo=:accnum");
		query.setParameter("accnum", accnum);
		List<Account> accounts= query.getResultList();
		return accounts.get(0); 
	}
	@Override
	public Account findAccount1(long accnum1) {
		// TODO Auto-generated method stub
		Query query= entitymanager.createQuery("from Account where accountNo=:accnum");
		query.setParameter("accnum", accnum1);
		List<Account> accounts= query.getResultList();
		return accounts.get(0); 
	}


	@Override
	public void depositWith(Transaction transaction) {
		// TODO Auto-generated method stub
		entitymanager.persist(transaction); 
	}


	@Override
    public void FundTransfer(Transaction transaction) {
           // TODO Auto-generated method stub
           entitymanager.persist(transaction);
     Transaction transaction1=new Transaction();
     Customer customer=new Customer();
     long toAcc=transaction.getToAccount().getAccountNo();
     Account toAccount=findAccount1(toAcc);
     customer=toAccount.getCustomer();
     transaction1.setCustomer(customer);
     transaction1.setTransactionDate(transaction.getTransactionDate());
     transaction1.setFromAccount(toAccount);
     transaction1.setTransactionType("credit");
     transaction1.setAmount(transaction.getAmount());
     transaction1.setDescription(transaction.getDescription());
     entitymanager.persist(transaction1);


    } 
                   

    
    
    




	@Override
    public List<Account> getOtherAccount(Integer customerId) {
           // TODO Auto-generated method stub

           Query query=entitymanager.createQuery("from Account acc where acc.customer.customerId!=:customId");
                               query.setParameter("customId", customerId);
                               
                               
                               List<Account> accounts= query.getResultList();
                               for (Account account : accounts) {
                                      System.out.println(account);
                               }
                               
                               
                               return accounts;
                        }


	@Override
	public List<Transaction> getTransactions(int customerId) {
		Query query = entitymanager.createQuery("FROM Transaction WHERE customerId=:custId");
		query.setParameter("custId", customerId);
		List<Transaction> transactions = query.getResultList();
		return transactions;
	} 
    


}


package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.dao.ITransactionDao;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("transactionService")
public class TransactionServiceImpl implements ITransactionService{
	@Autowired
	private ITransactionDao transactDao;
	
	@Override
	public void createTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		transactDao.createTransaction(transaction);
	}

	@Override
	public List<Transaction> getTransactions(Integer custId) {
		// TODO Auto-generated method stub
		return transactDao.getTransactions(custId);
	}

	@Override
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1, Date d2) {
		// TODO Auto-generated method stub
		return transactDao.getDatedTransactions(customerId, d1, d2);
	}

}

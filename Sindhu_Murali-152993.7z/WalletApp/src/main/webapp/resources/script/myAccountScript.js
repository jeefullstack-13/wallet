function validateFrom1()
{
  var c=createAccount.amount.value;
  var flag=false;
	if(c=="0.0"){
		document.getElementById('amountErrMsg').innerHTML=" * Please enter Initial Opening Amount.";
		
	}
	else{
		flag=true;
		document.getElementById('amountErrMsg').innerHTML="";
		//document.getElementById('pwdErrMsg').innerHTML="";
	}
	
  return flag;

}
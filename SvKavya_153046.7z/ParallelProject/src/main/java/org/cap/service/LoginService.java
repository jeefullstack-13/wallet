package org.cap.service;

import org.cap.Dao.ILoginDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginService implements ILoginService{
	
	@Autowired
	ILoginDao loginDao;

	@Override
	public boolean validateLogin(int customerId, String password) {
		
		return loginDao.validateLogin(customerId, password);
	}

	@Override
	public String getCustomerName(Integer custID) {
		
		return loginDao.getCustomerName(custID);
	}

	@Override
	public Customer findCustomer(int customerId) {
		
		return loginDao.findCustomer(customerId);
	}

}

function showYearDiv(){
                if(document.getElementById('rd').checked ||
                                                document.getElementById('fd').checked)
                                document.getElementById('yearsDiv').style.display='block';
                else
                                document.getElementById('yearsDiv').style.display='none';
}
function showBut(){
                if(document.getElementById('credit').checked){
                                document.getElementById('btnType').value="Deposit";
                }else{
                                document.getElementById('btnType').value="Withdraw";
                }
}







window.onload= function(){
                document.getElementById('yearsDiv').style.display='none';
}



function validateForm(){
                var uname=myform.customerId.value;
                var upwd=myform.customerPwd.value;
                
                var flag=false;
                if(uname==""||uname==null){
                                document.getElementById('userErrMsg').innerHTML=" * Please enter userName.";
                                
                }
                else if(upwd=="" || upwd==null)
                                {
                                flag=false;
                                document.getElementById('userErrMsg').innerHTML="";
                                document.getElementById('pwdErrMsg').innerHTML=" * Please enter password.";
                                }
                else{
                                flag=true;
                                document.getElementById('userErrMsg').innerHTML="";
                                document.getElementById('pwdErrMsg').innerHTML="";
                }

if(!uname.isDigit){
       document.getElementById('userErrMsg').innerHTML=" * customer Id should be a Integer.";       
}
return flag;
}

                


function openingBal() {
    var opnBal=myform.openingBalance.value;
    //var button=myform.accountType.value;
    var flag=false;
    if(document.getElementById('rd').checked)
           {
           if (opnBal<=500) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open RD is 500.";
           }
           
           else {
                  flag=true;
                
                  document.getElementById('errMsg').innerHTML="";
           }
           }
   
    else if (document.getElementById('fd').checked) {
           if (opnBal<=1000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open FD is 1000.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else if (document.getElementById('savings').checked) {
           if (opnBal<=1000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Savings Acc is 500.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else if (document.getElementById('current').checked) {
           if (opnBal<=10000) {
                  document.getElementById('errMsg').innerHTML=" * Minimum opening balance to open Current Acc is 10000.";
           }
           else {
                  flag=true;
                  document.getElementById('errMsg').innerHTML="";
           }
    }
    else{
           
           document.getElementById('errMsg').innerHTML="Please Choose any acount";
    }
    return flag;
}
function button(){
                //var TransactionType = null;
                var amt=myform1.amount.value;
                var desc=myform1.description.value;
                var flag=false;
                if(amt<1000){
                                document.getElementById('errMsg').innerHTML=" * amount to be deposited should be greater than 1000.";
    }
                else if(desc==""|| desc==null){
                                document.getElementById('errMsg').innerHTML="";
                                document.getElementById('ErrMsg').innerHTML=" * Please enter description.";
                                
                                
                }
                else{
                                flag=true;
                                document.getElementById('errMsg').innerHTML="";
                                document.getElementById('ErrMsg').innerHTML="";
                }
                return flag;
                }


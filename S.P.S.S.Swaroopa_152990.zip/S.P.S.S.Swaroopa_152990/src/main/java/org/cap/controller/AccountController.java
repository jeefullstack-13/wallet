package org.cap.controller;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;

import org.cap.model.Transaction;
import org.cap.service.IAccountService;
import org.cap.service.IWalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class AccountController {
	
	@Autowired
	private IWalletService walletService;
	
	@Autowired
	private IAccountService accountService;
	
	@RequestMapping("/validateLogin")
	public String validateLogin(ModelMap map,
								@RequestParam("customerId")String customerId,
								@RequestParam("password")String customerPwd,
								HttpSession session) {
			int custId=Integer.parseInt(customerId);
				if(walletService.validateLogin(custId,customerPwd)) {
					session.setAttribute("custId",custId);
					String custName=walletService.getcustName(custId);
					map.put("custName", custName);
					return "Main";
				}
				return "redirect:/";
	}
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccount(HttpSession session,
							   @ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer cId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer cust=new Customer();
		cust.setCustomerId(cId);
		account.setCustomer(cust);
		account.setStatus("active");
		accountService.createAccount(account);
		
		return "redirect:createAccount";
		
	}
	
	@RequestMapping("/showBalance")
	public String showAccountBalancePage(ModelMap map, HttpSession session) {
		Integer custId=Integer.parseInt(session.getAttribute("custId").toString());
List<Account> acc= accountService.getAccWithBal(custId);
		map.put("accounts", acc);
		return "showBalance";
	}
	
	@RequestMapping("/depositWithdrw")
	public String deposit(ModelMap map,HttpSession session,
			@ModelAttribute("transaction") Transaction transaction ) { 
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString()); 
	 List<Account> accNo=accountService.getAllAccounts(customerId);
		 map.put("accNum",accNo);
		 map.put("trans1", new Transaction());
		return "depositWithdrw";
	}
	
	@PostMapping(value="/addTransaction")
	public String addTransaction(
			@ModelAttribute("transaction") Transaction transaction1,
			HttpSession session) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer= walletService.findCustomer(customerId);
		
		transaction1.setTransactionDate(new Date());
		transaction1.setStatus("completed");
		transaction1.setCustomer(customer);
		
		long accNo=transaction1.getFromAccount().getAccountNo();
		Account account=accountService.findAccount(accNo);
		transaction1.setFromAccount(account);
		
		accountService.addTransaction(transaction1);
		
		return "redirect:depositWithdrw";
	}
	

	/*@RequestMapping("/fundTransfer")
    public String FundTransfer( HttpSession session,ModelMap map) {
          
 
           Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
           List<Account> accounts=accountService.getAllAccounts(customerId);
           map.put("accounts", accounts);
           map.put("deposit", new Transaction());  
           return "fundTransfer";
    }*/
	 
	@RequestMapping("/fundTransfer")
	public String fundTransfer(ModelMap map,HttpSession session,@ModelAttribute("transaction") Transaction transaction) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		 List<Account> accountNos=accountService.getAllAccounts(customerId);
			 map.put("accNos",accountNos);
		 List<Account> toAccountNos=accountService.getAllToAccounts(customerId);
		

		 map.put("toAccNos",toAccountNos);
		 map.put("transaction",new Transaction());
		
		return "fundTransfer";
		
	}

	@RequestMapping("/fundTransferring")
	public String fundTransferring(ModelMap map,HttpSession session,
			@ModelAttribute("transaction") Transaction transaction) {
		transaction.setTransactionDate(new Date());
		transaction.setStatus("Transaction successful");
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		
		transaction.setCustomer(customer);
		long accNo=transaction.getFromAccount().getAccountNo();
		long accNo1=transaction.getToAccount().getAccountNo();
		Account account=accountService.getAccount(accNo);
		Account account1=accountService.getAccount1(accNo1);
		transaction.setFromAccount(account);
		transaction.setToAccount(account1);
		transaction.setTransactionType("debit");
		Transaction transaction2=new Transaction();
		transaction2.setFromAccount(account1);
		transaction2.setTransactionType("credit");
	  

		accountService.fundTransfer(transaction);
		  accountService.fundTransfer(transaction2);
		
		return "redirect:/fundTransfer";
		
	}
	
	
	@RequestMapping("/printTransactions")
	public String getTransaction(HttpSession session,ModelMap map)
	{
		 Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		 List<Transaction> transaction=accountService.getTransactions(customerId);
		 
		 map.put("transactions",transaction);
		 return "printTransactions";
		 
	}
	
	
	@RequestMapping("/logout")
	public String showlogoutPage(HttpSession session) {
		session.invalidate();
		
		return "redirect:/";
	}
}

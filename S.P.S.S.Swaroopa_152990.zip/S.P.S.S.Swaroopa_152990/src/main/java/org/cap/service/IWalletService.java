package org.cap.service;

import org.cap.model.Customer;

public interface IWalletService {
	
	public boolean validateLogin(int customerId, String custPwd);
	public String getcustName(int customerId);
	public Customer findCustomer(int custId);
	
}

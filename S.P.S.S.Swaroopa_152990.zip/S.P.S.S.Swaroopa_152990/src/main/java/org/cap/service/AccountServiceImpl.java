package org.cap.service;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
public class AccountServiceImpl implements IAccountService {
			
			@Autowired
			private IAccountDao accountDao;
			
	@Override
	public void createAccount(Account acc) {
		accountDao.createAccount(acc);
		
	}

	@Override
	public List<Account> getAccWithBal(int custId) {
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
		Map<Account, Double> deMap = accountDao.getAmoutCrDe(str,custId);

	String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
	Map<Account, Double> cMap = accountDao.getAmoutCrDe(str1,custId);
		

	List<Account> accounts=getAllAccounts(custId);
	
	Iterator<Account> iterator= accounts.iterator();
	while(iterator.hasNext()) {
		Account account=iterator.next();
		double balance=0;
		double crAmt=0,deAmt=0;
		account.setUpdateBalance(0);
		
		if(cMap.get(account) ==null)
			crAmt=0;
		else
			crAmt=cMap.get(account);
		

		if( deMap.get(account) ==null)
			deAmt=0;
		else
			deAmt= deMap.get(account);
		
		balance=account.getOpeningBalance() +
				crAmt-deAmt;
		
		account.setUpdateBalance(balance);
	}
	return accounts;
}

	@Override
	public List<Account> getAllAccounts(int customerId) {
		
		return accountDao.getAllAccounts(customerId);
	}

	@Override
	public void addTransaction(Transaction trans1) {
			accountDao.addTransaction(trans1);
	}

	@Override
	public Account findAccount(long accountNo) {
		return accountDao.findAccount(accountNo);
	}

	@Override
	public List<Transaction> getTransactions(Integer id) {
		return accountDao.getTransactions(id);
	}
	


	@Override
	public Account getAccount(long accNo) {
		
		return accountDao.getAccount(accNo);
	}

	@Override
	public Account getAccount1(long accNo1) {
		
		return accountDao.getAccount1(accNo1);
	}

	@Override
	public void fundTransfer(Transaction transaction) {
		accountDao.fundTransfer(transaction);
		
	}

	@Override
	public List<Account> getAllToAccounts(Integer customerId) {
		
		return accountDao.getAllToAccounts(customerId);
	}

	

}

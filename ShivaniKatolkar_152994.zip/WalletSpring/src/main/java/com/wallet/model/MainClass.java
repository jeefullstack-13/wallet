package com.wallet.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer=new Customer();
		customer.setCustomerPwd("shivani123");
		customer.setFirstName("Shivani");
		customer.setLastName("Katolkar");
		customer.setLastLoginDate(new Date());
		customer.setEmail("shivani@gmail.com");
		customer.setMobile("8888777788");
		
		
		Account account=new Account();
		account.setAccountNo(1021101L);
		account.setAccountType("Savings");
		account.setCustomer(customer);
		
		Account accountRd=new Account();
		accountRd.setAccountNo(1021103L);
		accountRd.setAccountType("RD");
		accountRd.setCustomer(customer);
		accountRd.setYears(2);
		
		Account account1=new Account();
		account1.setAccountNo(1021102L);
		account1.setAccountType("Current");
		account1.setCustomer(customer);
		
		
		
		Transaction transaction1=new Transaction();
		transaction1.setCustomer(customer);
		transaction1.setFromAccount(account);
		transaction1.setAmount(1000);
		transaction1.setTransactionType("Debit");
		transaction1.setTransactionDate(new Date());
		
		
		Transaction transaction2=new Transaction();
		transaction2.setCustomer(customer);
		transaction2.setFromAccount(account);
		transaction2.setToAccount(account1);
		transaction2.setAmount(1000);
		transaction2.setTransactionType("Credit");
		transaction2.setTransactionDate(new Date());
		
		entityManager.persist(customer);
		entityManager.persist(account);
		entityManager.persist(account1);
		entityManager.persist(accountRd);
		entityManager.persist(transaction1);
		entityManager.persist(transaction2);
		transaction.commit();

	}

}

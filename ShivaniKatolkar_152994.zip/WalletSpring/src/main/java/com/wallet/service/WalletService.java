package com.wallet.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wallet.model.Account;
import com.wallet.model.Transaction;

public interface WalletService {
	
	public void createAcc(Account account);
	public List<Account> getAllAcc(int custId);
	public List<Account> getAccWithBalance(int custId);	
	public void addTransaction(Transaction transaction) ;
	public Account findAccount(long accountNo);
	public List<Transaction> getTransactions(Integer id);
	public Account getAccount(long accNo);
	public Account getAccount1(long accNo1);
	public void fundTransfer(Transaction transaction);
	public List<Account> getAllToAccounts(Integer customerId);
}

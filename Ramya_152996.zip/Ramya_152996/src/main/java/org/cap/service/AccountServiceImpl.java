package org.cap.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("accountService")
public class AccountServiceImpl implements IAccountSevice {

	@Autowired
	private IAccountDao accountDao;

	
	@Override
	public void createAccount(Account account) {
	
		accountDao.createAccount(account);
		
	}


	@Override
	public List<Account> getAllAccounts(int customerId) {
		return accountDao.getAllAccounts(customerId);
	}


	@Override
	public List<Account> getAccountWithBalance(int custId) {
		
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
		Map<Account, Double> deMap = accountDao.getAmoutCrDe(str,custId);

	String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
	Map<Account, Double> crMap = accountDao.getAmoutCrDe(str1,custId);
		

	List<Account> accounts=getAllAccounts(custId);
		
	Iterator<Account> iterator= accounts.iterator();
	while(iterator.hasNext()) {
		Account account=iterator.next();
		double balance=0;
		double crAmt=0,deAmt=0;
		account.setUpdateBalance(0);
		
		if(crMap.get(account) ==null)
			crAmt=0;
		else
			crAmt=crMap.get(account);
		

		if( deMap.get(account) ==null)
			deAmt=0;
		else
			deAmt= deMap.get(account);
		
		
		
		balance=account.getOpeningBalance() +
				crAmt-deAmt;
		
		account.setUpdateBalance(balance);
		
	}
	
	
	return accounts;
	
	
}


	@Override
	public Account findAccount(long accNo) {
	
		return accountDao.findAccount(accNo);
	}


	@Override
	public void addTransaction(Transaction transaction) {
		accountDao.addTransaction(transaction);
		
	}


	@Override
	public void startTransaction(Transaction transaction) {
		accountDao.startTransaction(transaction);
		
	}


	@Override
	public List<Transaction> getAllTransactions(Integer customerId) {
		
		return accountDao.getAllTransactions(customerId);
	}

	@Override
	public List<Account> getAllToAccounts(Integer customerId) {

		return accountDao.getAllToAccounts(customerId);
	}
	
	@Override
	public void fundTransfer(Transaction transaction2) {
		
		accountDao.fundTransfer(transaction2);
	}

	@Override
	public Account getAccount(long accNo) {
		
		return accountDao.getAccount(accNo);
	}

	@Override
	public Account getAccount1(long accNo1) {
		
		return accountDao.getAccount1(accNo1);
	}
	@Override
	public List<Transaction> getTransactions(Integer id) {
		
		return accountDao.getTransactions(id);
	}
}

package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService {
	@Autowired
private ILoginDao loginDao;

@Override
public boolean validateLogin(int customerId, String customerPwd) {
	return loginDao.validateLogin(customerId, customerPwd);
}

@Override
public String getCustomerName(int customerId) {

	return loginDao.getCustomerName(customerId);
}

@Override
public Customer findCustomer(int customerId) {

	return loginDao.findCustomer(customerId);
}
	
}

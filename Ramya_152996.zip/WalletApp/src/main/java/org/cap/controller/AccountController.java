package org.cap.controller;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Login;
import org.cap.model.Transaction;
import org.cap.service.IAccountSevice;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	@Autowired
private ILoginService loginService;
	
	@Autowired
	private IAccountSevice accountService;
	private Customer customer;
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("customerId") String customerId,
			@RequestParam("customerPwd") String customerPwd,
			HttpSession session) {
		
		Integer custId=Integer.parseInt(customerId);
		
		
		if(loginService.validateLogin(custId, customerPwd)) {
		
			session.setAttribute("custId", custId);
			
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			return "main";
		}
		return "redirect:/";
	}
	
	
	@RequestMapping("/createAccount")
	public String showCreateDetails(ModelMap map) {
			map.put("account", new Account());
			return "createAccount";
			
	}
	
	@RequestMapping("/withdraw")
	public String showTransaction(ModelMap map, HttpSession session) {
	
			Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
			List<Account> accounts=accountService.getAllAccounts(custId);
			
	
			map.put("accounts", accounts);
			map.put("transaction", new Transaction());
			
			return "withdraw";
			
		} 
	
	
		
		
		
		@RequestMapping("/fundTransfer")
		public String fundTransfer(ModelMap map,HttpSession session,@ModelAttribute("transaction") Transaction transaction) {
			
			Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
			
			 List<Account> accountNos=accountService.getAllAccounts(customerId);
				 map.put("accNos",accountNos);
			 List<Account> toAccountNos=accountService.getAllToAccounts(customerId);
			

			 map.put("toAccNos",toAccountNos);
			 map.put("transaction",new Transaction());
			
			return "fundTransfer";
			
		} 
	 

		@RequestMapping("/printTransactions")
		public String showTransactionSummaryPage(ModelMap map,HttpSession session) {
			
			Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
			List<Transaction> transaction= accountService.getTransactions(custId);
			for (Transaction transaction2 : transaction) {
				System.out.println(transaction2);
			}
			map.put("transactions", transaction);
			return "printTransactions";
		}
			@RequestMapping("/Logout")
			public String showLogoutPage(HttpSession session) {
				session.invalidate();
				return"redirect:/";
			} 
	 

	
	

	@PostMapping(value="/addTransfer")
	public String addTransfer(ModelMap map,
			@ModelAttribute("transaction") Transaction transaction,
			HttpSession session) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer= loginService.findCustomer(customerId);
		
		transaction.setTransactionDate(new Date());
		transaction.setStatus("completed");
		transaction.setCustomer(customer);
		Integer custId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer2=new Customer();
		long accNo1=transaction.getFromAccount().getAccountNo();
		long accNo2=transaction.getToAccount().getAccountNo();
		
		Account account1=accountService.findAccount(accNo1);
		Account account2=accountService.findAccount(accNo2);
		
		transaction.setFromAccount(account1);
		transaction.setToAccount(account2);
		transaction.setTransactionType("debit");
		accountService.startTransaction(transaction);
	
		return "redirect:fundTransfer";
		
	}
		  
		@RequestMapping("/ftransfer")
			public String fundTransferring(ModelMap map,HttpSession session,
					@ModelAttribute("transaction") Transaction transaction) {
				transaction.setTransactionDate(new Date());
				transaction.setStatus("Transaction successful");
				Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
				Customer customer=new Customer();
				customer.setCustomerId(customerId);
				
				transaction.setCustomer(customer);
				long accNo=transaction.getFromAccount().getAccountNo();
				long accNo1=transaction.getToAccount().getAccountNo();
				Account account=accountService.getAccount(accNo);
				Account account1=accountService.getAccount1(accNo1);
				transaction.setFromAccount(account);
				transaction.setToAccount(account1);
				transaction.setTransactionType("debit");
				Transaction transaction2=new Transaction();
				transaction2.setFromAccount(account1);
				transaction2.setTransactionType("credit");
			  

				accountService.fundTransfer(transaction);
				accountService.fundTransfer(transaction2);
				System.out.println(transaction);
				System.out.println(transaction2);
				return "redirect:/fundTransfer";
				
			
		 

	}
	
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,
			@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer= loginService.findCustomer(customerId);
		account.setCustomer(customer);
		account.setStatus("active");
		accountService.createAccount(account);
		
		return "redirect:createAccount";
	}
	
	@PostMapping(value="/addTransaction")
	public String addTransaction(
			@ModelAttribute("transaction") Transaction transaction,
			HttpSession session) {
		
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer= loginService.findCustomer(customerId);
		
		transaction.setTransactionDate(new Date());
		transaction.setStatus("completed");
		transaction.setCustomer(customer);
		
		long accNo=transaction.getFromAccount().getAccountNo();
		Account account=accountService.findAccount(accNo);
		transaction.setFromAccount(account);
		
		accountService.addTransaction(transaction);
		
		return "redirect:withdraw";
	}
	
	

	@RequestMapping("/showBalance")
	public String showBalanceDetails(ModelMap map,
			HttpSession session) {
		
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts= accountService.getAccountWithBalance(custId);
		
		map.put("accounts", accounts);
		
		return "showBalance";
	}
	
	

	@RequestMapping("/logout")
	public String logOut(HttpSession session) {
		session.invalidate();
		return "redirect:index";
		
	}
	
	
}

package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountDao {
	
	void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId);
	public Account findAccount(long accNo);

	public void addTransaction(Transaction transaction);
	void startTransaction(Transaction transaction);
	public List<Transaction> getAllTransactions(Integer customerId);
	public Account getAccount(long accNo);

	public Account getAccount1(long accNo1);

	void fundTransfer(Transaction transaction);
	public List<Transaction> getTransactions(Integer custId);
	public List<Account> getAllToAccounts(Integer custId);


}

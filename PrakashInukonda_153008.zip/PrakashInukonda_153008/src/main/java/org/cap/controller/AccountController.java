package org.cap.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.AccountService;
import org.cap.service.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ModelAndView;
@SessionScope
@Controller
public class AccountController {
   @Autowired
   private WalletService walletService;
   @Autowired
   private AccountService accountService;
   
   //private Customer customer;
   Integer idcust;
  
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
		
			@RequestParam("userName")Integer id,@RequestParam("userPwd") String password,HttpSession session) {
		
		List<Customer> customer=walletService.getLogin(id,password);
		
		if(!customer.isEmpty())
		{
			session.setAttribute("custId",id);
			String custName=walletService.getCustomerName(id);
			map.put("custName", custName);
			return "main";
		}
		
		return "redirect:/";
	}
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
	}
	
	
	
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,
			@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		//Customer customer= loginService.findCustomer(customerId);
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		account.setCustomer(customer);
		
		account.setStatus("active");
		
		accountService.createAccount(account);
		
		return "redirect:createAccount";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session)
	{
		session.invalidate();
		return "redirect:/";
		
	}
	
	
	
	@RequestMapping("/showBalance")
	public String showBalancePage(ModelMap map,HttpSession session) {
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> l=accountService.getAccountWithBalance(customerId);
		map.put("accounts", l);
		
		
		
		return "showBalance";
	}

   @RequestMapping("/deposit")
	public String depositPage(ModelMap map,HttpSession session){
	   Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> l=accountService.getAllAccount(customerId);
		map.put("accounts", l);
		map.put("transaction", new Transaction());
		return "deposit";
	}
	
	@RequestMapping("/depositDone")
	public String depositDone(
			@ModelAttribute("transaction") Transaction transaction,
			HttpSession session)
	{
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
						
		
		Customer customer= walletService.findCustomer(customerId);
		System.out.println(customer);
		
		transaction.setTransactionDate(new Date());
		transaction.setStatus("completed");
		transaction.setCustomer(customer);
		
		long accNo=transaction.getFromAccount().getAccountNo();
		
		System.out.println(accNo);
		Account account=accountService.findAccount(accNo);
		transaction.setFromAccount(account);
		
		
		System.out.println(account);
		accountService.createTransactionAccount(transaction);
		
		return "redirect:deposit";
	}
	
	
	
	
	  @RequestMapping("/fundTransfer")
		public String fundTransferPage(ModelMap map,HttpSession session){
		 /*  Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
			List<Account> l=accountService.getAllAccount(customerId);
			
		//	List<Account> ls=accountService.getOtherAccount(customerId);
		//	map.put("others", ls);
			map.put("accounts", l);
			map.put("transaction", new Transaction());*/
		  
		  Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
			List<Account> l=accountService.getAllAccount(customerId);
			
			List<Account> ls=accountService.getOtherAccount(customerId);
			
			map.put("accounts", l);
			map.put("others", ls);
			map.put("transaction1", new Transaction());
			return "fundtransfer1";
		}

	
	
		
		@RequestMapping("/transferDone")
		public String transferDone(@ModelAttribute("transaction1") Transaction transaction,
				HttpSession session)
		{
	Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
				
	
			Customer customer= walletService.findCustomer(customerId);
			System.out.println(customer);
			
			transaction.setTransactionDate(new Date());
			transaction.setStatus("completed");
			transaction.setCustomer(customer);
			
			long accNo=transaction.getFromAccount().getAccountNo();
			
			System.out.println(accNo);
			Account account=accountService.findAccount(accNo);
			transaction.setFromAccount(account);
			
			
           long accNo1=transaction.getToAccount().getAccountNo();
			
			System.out.println(accNo1);
			Account account1=accountService.findAccount(accNo);
			transaction.setToAccount(account1); 
			
			transaction.setTransactionType("debit");
			System.out.println(account);
			accountService.createTransactionAccount(transaction);
			
			return "redirect:fundTransfer";
	
	
	
	
		}
	  
		@RequestMapping("/printTransaction")
		public String getTransaction(HttpSession session,ModelMap map)
		{
			 Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
			 List<Transaction> transaction=accountService.getTransactions(customerId);
			 
			 map.put("transactions",transaction);
			// map.put("transactions2",transaction);
			 map.put("transaction", new Transaction());
			 return "printTransaction";
			 
		}
		
	  
	  @RequestMapping("/printDone")
	  public String printTrans(HttpSession session,ModelMap map,@RequestParam("transactionDate1") String date1,@RequestParam("transactionDate2") String date2) throws ParseException
	  {Date d1=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
	  Date d2=new SimpleDateFormat("yyyy-MM-dd").parse(date2);
		
		  
		  
		 System.out.println("date is :"+d1+","+"date 2 is"+d2);
		  Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		  

		 List<Transaction> transaction=accountService.getDatedTransactions(customerId,d1,d2);
		 
		 
		 List<Transaction> transaction1=accountService.getTransactions(customerId);
		 		 
		 
		 
		 map.put("transactions",transaction1);
		 map.put("transactionn", transaction);
		 map.put("transaction", new Transaction());
		 return "printTransaction";
		 
		 
	  }
	
	
}

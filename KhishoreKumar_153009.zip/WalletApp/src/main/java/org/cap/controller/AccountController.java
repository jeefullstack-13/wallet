package org.cap.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.DatePeriod;
import org.cap.model.Transaction;
import org.cap.service.IAccountService;
import org.cap.service.ILoginService;
import org.cap.service.ITransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	
	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IAccountService acccountService;
	
	@Autowired
	private ITransactionService transactionService;
	
	private List<Transaction> dates=null;
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		
		session.invalidate();
		return "redirect:/";
	}
	

	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("customerId") String customerId,
			@RequestParam("customerPwd") String customerPwd,
			HttpSession session) {
		
		Integer custId=Integer.parseInt(customerId);
		
		
		if(loginService.validateLogin(custId, customerPwd)) {
			//Store CustId into the session object
			session.setAttribute("custId", custId);
			
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			
			return "main";

		}
		
		return "redirect:/";
	}
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		
		map.put("account", new Account());
		return "createAccount";
	}
	
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,
			@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer= loginService.findCustomer(customerId);
		/*Customer customer=new Customer();
		customer.setCustomerId(customerId);*/
		account.setCustomer(customer);
		
		account.setStatus("active");
				
		acccountService.createAccount(account);
		
		return "redirect:createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalanceDetails(ModelMap map,
			HttpSession session) {
		
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts= acccountService.getAccountWithBalance(custId);
		
		map.put("accounts", accounts);
		
		return "showBalance";
	}
	
	@RequestMapping("/deposit")
	public String depositPage(ModelMap map,HttpSession session) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Account> accounts1 = acccountService.getAllAccounts(customerId);
		map.put("transaction1", new Transaction());
		map.put("accounts1", accounts1);
		return "deposit";
	}
	
	@RequestMapping("/withdraw")
	public String withdrawPage(ModelMap map,HttpSession session) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		
		List<Account> accounts2 = acccountService.getAllAccounts(customerId);
		map.put("transaction2", new Transaction());
		map.put("accounts2", accounts2);
		return "withdraw";
	}
	
	@RequestMapping("/deptransact")
	public String transactionDeposit(@RequestParam("fromAcc1")int accountId,@ModelAttribute("transaction1")Transaction transaction,HttpSession session) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		transaction.setCustomer(customer);
		transaction.setTransactionDate(new Date());
		transaction.setStatus("completed");
		transaction.setTransactionType("credit");
		Account account=acccountService.findAccount(accountId);
		transaction.setFromAccount(account);
		transaction.setToAccount(null);
		
		transactionService.createTransaction(transaction);
		
		return "redirect:/deposit";
	}
	
	@RequestMapping("/withtransact")
	public String transactionWithdraw(@RequestParam("fromAcc2")int accountId,@ModelAttribute("transaction2")Transaction transaction,HttpSession session) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		transaction.setCustomer(customer);
		transaction.setTransactionDate(new Date());
		transaction.setStatus("completed");
		transaction.setTransactionType("debit");
		Account account=acccountService.findAccount(accountId);
		transaction.setFromAccount(account);
		transaction.setToAccount(null);
		
		transactionService.createTransaction(transaction);
		
		return "redirect:/withdraw";
	}
	
	
	@RequestMapping("/fundTrans")
	public String fundTransferPage(HttpSession session,ModelMap map) {
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		
		map.put("fund", new Transaction());
		
		List<Account> fAccounts = acccountService.getAllAccounts(customerId);
		map.put("faccounts", fAccounts);
		
		List<Account> tAccounts = acccountService.getAccounts(customerId);
		map.put("taccounts", tAccounts);
		
		return "fundTransfer";
	}
	
	@RequestMapping("/transfer")
	public String transferFund(@RequestParam("fromAcc")int fromAccountId,
			@RequestParam("toAcc")int toAccountId,
			@ModelAttribute("fund")Transaction fund,
			HttpSession session) {
	
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer= loginService.findCustomer(customerId);
		fund.setCustomer(customer);
		fund.setTransactionDate(new Date());
		fund.setStatus("completed");
		fund.setTransactionType("debit");
		Account account1=acccountService.findAccount(fromAccountId);
		fund.setFromAccount(account1);
		Account account2=acccountService.findAccount(toAccountId);
		fund.setToAccount(account2);
		
		acccountService.fundTransfer(fund);	
		
		return "redirect:/fundTrans";
	}
	
	@RequestMapping("/transSummary")
	public String summaryPage(HttpSession session,ModelMap map) {
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		List<Transaction> transactions=transactionService.getTransactions(customerId);
		map.put("transDate", transactions);
		map.put("listoftrans", null);
		return "summary";
	}
	
	@RequestMapping("/showtransaction")
	public String transsummary(
			@RequestParam("date1")String date1,
			@RequestParam("date2")String date2,
			HttpSession session,ModelMap map) throws ParseException {
		
		System.out.println(date1);
		System.out.println(date2);
		
		Date d1=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
		Date d2=new SimpleDateFormat("yyyy-MM-dd").parse(date2);
		
		System.out.println(d1);
		System.out.println(d2);
		
		List<Transaction> transaction=null;
		
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
	
		transaction=transactionService.getDatedTransactions(customerId,d1,d2);
				
		List<Transaction> transactionDates=transactionService.getTransactions(customerId);
		
		map.put("listoftrans", transaction);
		map.put("transDate", transactionDates);
		
		return "summary";
	}
	
}

package org.cap.service1;

public interface ILoginService {
	public boolean validateLogin(int customerId,String password);
	  public String getCustomerName(int customerId);
}

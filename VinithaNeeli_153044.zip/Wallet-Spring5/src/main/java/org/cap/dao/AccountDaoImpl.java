package org.cap.dao;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

/*import javax.transaction.Transactional;*/

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;


@Repository("accountDao")
public class AccountDaoImpl implements AccountDao{
  
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	EntityManager entityManager;
	
	@Override
	@Transactional
	public void createAccount(Account account) {
		Query query=entityManager.createQuery("select max(accountNo) from Account");
		List<Long> max=query.getResultList();
		account.setAccountNo(max.get(0)+1);
		entityManager.persist(account);
		
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerId) {
		Query query=entityManager.createQuery("from Account acc where acc.customer.customerId=:custId");
		query.setParameter("custId", customerId);
		Query query2=entityManager.createQuery("from Transaction t where t.customer.customerId=:custId");
		query2.setParameter("custId", customerId);
		List<Account> accounts=query.getResultList();
		List<Transaction> transactions=query2.getResultList();
		return accounts;
	}
	/*@Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCreditDe(String strQuery,int customerId){
		
		Query query2=entityManager.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=transactions.stream().collect(Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount)));
		return map;
	}*/
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId){
	
		
		Query query2=entityManager
				.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(Transaction::getFromAccount,
					Collectors.summingDouble(Transaction::getAmount))
				);
		return map;
	}
	
	@Override
	public List<Long> deposit(int custoId) {
		Query query=entityManager.createQuery("select accountNo from Account acc where acc.customer.customerId=:custId");
		query.setParameter("custId", custoId);
		List<Long> accountNos=query.getResultList();
		return accountNos;
		/*map.put("accNos",accountNos);*/
	}

	@Override
	@Transactional
	public void depositOrWithdraw(Transaction transaction) {
		entityManager.persist(transaction);
		System.out.println("hiiii");
		
	}
	@Override
	public Account getAccount(long accountNo) {
		Query query= entityManager.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accountNo);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllToAccounts(Integer customerId) {
		Query query=entityManager.createQuery("from Account acc where acc.customer.customerId!=:custId");
		query.setParameter("custId", customerId);
		
		List<Account> accounts=query.getResultList();
		
		return accounts;
		
	}

	@Override
	@Transactional
	public void fundTransfer(Transaction transaction) {
		entityManager.persist(transaction);
        Transaction transaction1=new Transaction();
        Customer customer=new Customer();
        long toAcc=transaction.getToAccount().getAccountNo();
        Account toAccount=getAccount1(toAcc);
        customer=toAccount.getCustomer();
        transaction1.setCustomer(customer);
        transaction1.setTransactionDate(transaction.getTransactionDate());
        transaction1.setFromAccount(toAccount);
        transaction1.setTransactionType("credit");
        transaction1.setAmount(transaction.getAmount());
        transaction1.setDescription(transaction.getDescription());
        entityManager.persist(transaction1);

		
		
	}

	@Override
	public Account getAccount1(long accNo1) {
		Query query= entityManager.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accNo1);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}
	/*@Transactional
	public List<Transaction> getTransactions(Integer customerId,Date fromDate,Date toDate) {
		
		Query query=entityManager.createQuery("from Transaction t WHERE  (transactionDate BETWEEN transactionDate=:frDate AND transactionDate=:toDate) "
			                                     	+ " AND t.customer.customerId=:custId");

		
		query.setParameter("frDate", fromDate);
		query.setParameter("toDate", toDate);
		
		List<Transaction> transactions= query.getResultList();
		return transactions;
	}*/

	@Override
	@Transactional
	public List<Transaction> getTransactions(int customerId) {

Query query=entityManager.createQuery("from Transaction t where t.customer.customerId=:custId");
query.setParameter("custId", customerId);
List<Transaction> transactions= query.getResultList();
return transactions;
	}

	@Override
	public List<Transaction> printDatedTransactions(int customerId, java.util.Date d1, java.util.Date d2) {
		Calendar cal = Calendar.getInstance();
		 cal.setTime(d2);
		 cal.add(Calendar.DATE, 1); //minus number would decrement the days
		 java.util.Date d3= cal.getTime(); 
		Query query= entityManager.createQuery("from Transaction tx where tx.customer.customerId=? and transactionDate between ? and ?");
		query.setParameter(0, customerId);
		query.setParameter(1,d1);
		query.setParameter(2,d3);
		
		List<Transaction> transactions= query.getResultList();
		return transactions;
	}

	

	
}

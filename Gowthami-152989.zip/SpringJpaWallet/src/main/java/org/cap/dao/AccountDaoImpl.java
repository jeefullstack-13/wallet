package org.cap.dao;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;


import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("accountDao")
@Transactional
public class AccountDaoImpl implements IAccountDao {
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entitymanager;

	@Override
	@Transactional
	public void createAccount(Account account) {
Query query= entitymanager.createQuery("select max(accountNo) from Account");
	List<Long> max= query.getResultList();
	account.setAccountNo(max.get(0)+1);
	entitymanager.persist(account);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerid) {
		Query query1= entitymanager.createQuery("from Account acc where acc.customer.customerId=:custId");
		query1.setParameter("custId", customerid);

		List<Account> accounts= query1.getResultList();
		return accounts;
	}

	
	@Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCrDe(String strQuery, int customerId) {

		Query query2=entitymanager.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<Transaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream().collect(Collectors.groupingBy(Transaction::getFromAccount,Collectors.summingDouble(Transaction::getAmount))
				                      );
		return map;
	}

	@Override
	@Transactional(readOnly=true)
	public List<Account> getToaccounts(Integer customerId) {
		Query query1= entitymanager.createQuery("from Account acc where acc.customer.customerId!=:custId");
		query1.setParameter("custId", customerId);

		List<Account> account= query1.getResultList();
		return account;
	}

	@Override
	public Account findAccount(int fromAccId) {
		Account account1=entitymanager.find(Account.class,fromAccId);
		return account1;
	}

}

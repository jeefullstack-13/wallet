package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.model.Transaction;

public interface ITransactionservice {

	public void createAccount(Transaction transaction);
	public List<Transaction> getTransactions(Integer custId);
	public void createTransaction(Transaction transaction);
	public void fundTransfer(Transaction transaction1);
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1, Date d2);
}

package org.cap.service;

import org.cap.model.Customer;

public interface BankService {

	public boolean validateLogin(int customerId, String customerPwd);

	public String getCustomerName(int custId);

	public Customer findCustomer(Integer customerId);

}

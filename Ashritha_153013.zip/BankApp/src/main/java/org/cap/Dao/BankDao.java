package org.cap.Dao;

import org.cap.model.Customer;

public interface BankDao {

	public boolean validateLogin(int customerId,String customerPwd);

	public String getCustomerName(int custId);

	public Customer findCustomer(Integer customerId);

}

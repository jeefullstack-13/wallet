package org.cap.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainApp {
	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer=new Customer();
		customer.setCustomerPwd("123");
		customer.setFirstName("Ankit");
		customer.setLastName("Malik");
		customer.setLastLoginDate(new Date());
		/*customer.setEmail("Ash@email.com");
		customer.setMobile("9000781570");
		customer.setStatus("active");*/
		
		
		Account account=new Account();
		account.setAccountNo(1234567892L);
		account.setAccountType("savings");
		account.setOpeningDate(new Date());
		//account.setOpeningBalance(1000);
		//account.setStatus("active");
		
		account.setCustomer(customer);
		

		Account accountrd1=new Account();
		accountrd1.setAccountNo(123456000L);
		accountrd1.setAccountType("rd");
		accountrd1.setCustomer(customer);
		accountrd1.setOpeningDate(new Date());
		//accountrd.setOpeningBalance(1000);
		//accountrd.setStatus("active");
		
		
	
	
		Account account1=new Account();
		account1.setAccountNo(123456L);
		//account1.setAccountType("current");
		//account1.setCustomer(customer);
		//account1.setOpeningDate(new Date());
		//account1.setOpeningBalance(1000);
		//account1.setStatus("active");
		
		
		
		Transaction transaction2=new Transaction();
		transaction2.setCustomer(customer);
		transaction2.setFromAccount(account);
		transaction2.setAmount(1000);
		transaction2.setTransactionType("debit");
		transaction2.setTransactionDate(new Date());
		
		
		Transaction transaction3=new Transaction();
		transaction3.setCustomer(customer);
		transaction3.setFromAccount(account);
		transaction3.setToAccount(account1);
		transaction3.setAmount(1000);
		transaction3.setTransactionType("credit");
		transaction3.setTransactionDate(new Date());
		
		entityManager.persist(customer);
		entityManager.persist(account);
		entityManager.persist(account1);
		entityManager.persist(transaction2);
		entityManager.persist(transaction3);
		entityManager.persist(accountrd1);
		transaction.commit();


	}




}

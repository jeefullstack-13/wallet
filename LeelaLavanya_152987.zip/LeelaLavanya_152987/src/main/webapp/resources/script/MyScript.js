function showYearDiv(){
	if(document.getElementById('Rd').checked ||
			document.getElementById('Fd').checked)
		document.getElementById('yearsDiv').style.display='block';
	else
		document.getElementById('yearsDiv').style.display='none';
}


window.onload= function(){
	document.getElementById('yearsDiv').style.display='none';
}
function showButton(){
	if(document.getElementById('credit').checked){
		document.getElementById('btnType').value="Deposit";
	}else{
		document.getElementById('btnType').value="Withdraw";
	}
}


function validateForm(){
	alert('Hello!..');
	var customerId=myform.CustomerId.value;
	var password=myform.Password.value;
	var flag=false;
	if(customerId==""||customerId==null){
		document.getElementById('userErrMsg').innerHTML="*Please Enter CustomerId*";
	}
	else if(password==""||password==null){
		flag=false;
		document.getElementById('pwdErrMsg').innerHTML="*Please Enter password*";
	}
	else{
		flag=true;
		document.getElementById('userErrMsg').innerHTML="";
			document.getElementById('pwdErrMsg').innerHTML="";
	}
	return flag;
}
package org.cap.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.cap.dao.IAccountDao;
import org.cap.model.AccountDetails;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("acccountService")
public class AccountServiceImpl implements IAccountService {
	
	@Autowired
	private IAccountDao accountDao;

	@Override
	public void createAccount(AccountDetails account) {
		
		accountDao.createAccount(account);
		
	}

	@Override
	public List<AccountDetails> getAccountWithBalance(Integer custId) {
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
		Map<AccountDetails, Double> deMap = accountDao.getAmoutCrDe(str,custId);

	String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
	Map<AccountDetails, Double> crMap = accountDao.getAmoutCrDe(str1,custId);
		

	List<AccountDetails> accounts=getAllAccounts(custId);
	
	
	
	Iterator<AccountDetails> iterator= accounts.iterator();
	while(iterator.hasNext()) {
		AccountDetails account=iterator.next();
		double balance=0;
		double crAmt=0,deAmt=0;
		account.setUpdateBalance(0);
		
		if(crMap.get(account) ==null)
			crAmt=0;
		else
			crAmt=crMap.get(account);
		

		if( deMap.get(account) ==null)
			deAmt=0;
		else
			deAmt= deMap.get(account);
		
		
		
		balance=account.getOpeningBalance() +
				crAmt-deAmt;
		
		account.setUpdateBalance(balance);
		
	}
	
	
	return accounts;
	
	
	}

	

	@Override
	public List<AccountDetails> getAllAccounts(int customerId) {
		return accountDao.getAllAccounts(customerId);
		
}


	@Override
	public void addTransaction(Transaction transaction) {
		accountDao.addTransaction(transaction);
		
	}

	@Override
	public AccountDetails findAccount(long accountNo) {
		
		return accountDao.findAccount(accountNo);
	}

	@Override
	public List<Transaction> getTransaction(Integer custId) {
		// TODO Auto-generated method stub
		return accountDao.getTransaction(custId);
	}

	@Override
	public void fundTransfer(Transaction transaction2) {
		// TODO Auto-generated method stub
		accountDao.fundTransfer(transaction2);
	}

	@Override
	public AccountDetails getAccount(long accNo) {
		// TODO Auto-generated method stub
		return accountDao.getAccount(accNo);
	}

	@Override
	public AccountDetails getAccount1(long accNo1) {
		// TODO Auto-generated method stub
		return accountDao.getAccount1(accNo1);
	}

	@Override
	public List<AccountDetails> getAllToAccounts(Integer customerId) {
		// TODO Auto-generated method stub
		return accountDao.getAllToAccounts(customerId);
	}
}

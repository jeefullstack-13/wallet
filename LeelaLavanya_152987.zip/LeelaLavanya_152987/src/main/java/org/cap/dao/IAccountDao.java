package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.AccountDetails;
import org.cap.model.Transaction;

public interface IAccountDao {
	public void createAccount(AccountDetails account);

	public List<AccountDetails> getAllAccounts(int customerId);

	public Map<AccountDetails, Double> getAmoutCrDe(String str, int customerId);



	public void addTransaction(Transaction transaction1);

	AccountDetails findAccount(long accountNo);
	public List<Transaction> getTransaction(Integer custId);
	public void fundTransfer(Transaction transaction2);

	public AccountDetails getAccount(long accNo);

	public AccountDetails getAccount1(long accNo1);

	List<AccountDetails> getAllToAccounts(Integer customerId);
}

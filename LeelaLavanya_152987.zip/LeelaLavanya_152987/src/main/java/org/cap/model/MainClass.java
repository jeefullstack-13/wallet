package org.cap.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer1=new Customer();
		customer1.setPassword("123");
		customer1.setFirstName("jill");
		customer1.setLastName("jerry");
		customer1.setLastLoginDate(new Date());
		
		
		
		AccountDetails account=new AccountDetails();
		account.setAccountNumber(123456756l);
		account.setAccountType("savings");
		
	
		account.setCustomer(customer1);
		
		AccountDetails account1=new AccountDetails();
		account1.setAccountNumber(32435458L);
		account1.setAccountType("current");
		account1.setCustomer(customer1);
		
		
		
		Transaction transaction2=new Transaction();
		transaction2.setCustomer(customer1);
		transaction2.setFromAccount(account);
		transaction2.setAmount(1000);
		transaction2.setTransactionType("debit");
		transaction2.setTransactionDate(new Date());
		
		
		Transaction transaction3=new Transaction();
		transaction3.setCustomer(customer1);
		transaction3.setFromAccount(account);
		transaction3.setToAccount(account1);
		transaction3.setAmount(1000);
		transaction3.setTransactionType("credit");
		transaction3.setTransactionDate(new Date());
		
		entityManager.persist(customer1);
		entityManager.persist(account);
		entityManager.persist(account1);
		entityManager.persist(transaction2);
		entityManager.persist(transaction3);
		transaction.commit();


	}

}
